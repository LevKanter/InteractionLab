// in here: I can use jQuery functionality defined in the script I included above
			
// button has class .button
// div has an id box

console.log("Hey");